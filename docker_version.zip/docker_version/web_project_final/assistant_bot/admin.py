from django.contrib import admin
from .models import AddressBook, NoteBook

# Register your models here.
admin.site.register(AddressBook)
admin.site.register(NoteBook)
